export interface message{
    time:Date;
    message:String;
    sender:boolean;
}