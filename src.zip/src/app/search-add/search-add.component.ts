import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DataproviderService } from '../dataprovider.service';
import { chatItem } from '../model/chat-item';
import { message } from '../model/message';
@Component({
  selector: 'app-search-add',
  templateUrl: './search-add.component.html',
  styleUrls: ['./search-add.component.css']
})
export class SearchAddComponent {
  constructor(private dataService:DataproviderService,private datepipe:DatePipe,private router:Router){}
  onClickAdd(){
    let newChatName=prompt('Create a New Chat');
    if(newChatName){
      let currentDateTime=new Date();
      let newChat!:chatItem;
      // let WelcomeMessage:message={message:'Hello, Welcome',time:currentDateTime,sender:false};
      newChat=new chatItem(0,newChatName!,'',currentDateTime,[]);

      this.dataService.addNewChat(newChat).subscribe((newItem)=>{
        this.dataService.fetchChatList().subscribe((data)=>{
          this.dataService.updateSubject(data);
          this.router.navigate(['/chats/',newItem.id]);
        });
      console.log('New Contact Added:',newItem.id);
    }
    );
    }
  }
}
