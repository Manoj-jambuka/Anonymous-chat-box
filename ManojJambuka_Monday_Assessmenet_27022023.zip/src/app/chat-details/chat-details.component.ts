import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { chatItem } from '../model/chat-item';
import { ActivatedRoute, Router } from '@angular/router';
import { DataproviderService } from '../dataprovider.service';
import { FormControl, FormControlName, Validators } from '@angular/forms';
import { message } from '../model/message';

@Component({
  selector: 'app-chat-details',
  templateUrl: './chat-details.component.html',
  styleUrls: ['./chat-details.component.css']
})
export class ChatDetailsComponent implements OnInit {
  chatId!:number;  
  chat!:chatItem;
  contactLoaded:boolean=false;
  Sender:boolean=true;
  messageList!:message[];
  constructor(private route:ActivatedRoute,private dataService:DataproviderService, private router:Router){
  }
    ngOnInit(): void {
      // this.getContact();
      this.route.paramMap.subscribe(params=>{
        this.chatId=+params.get('id')!;
        this.dataService.getChatById(this.chatId).subscribe(data=>{
         this.chat=data;
         this.contactLoaded=true;
         this.messageList=this.chat.messages;
         console.log(this.messageList);
       });
     });
    }
    @ViewChild('newMessage') newMessage!:ElementRef;

    getContact (){
      this.route.paramMap.subscribe(params=>{
         this.chatId=+params.get('id')!;
         this.dataService.getChatById(this.chatId).subscribe(data=>{
          this.chat=data
        });
      });
    }
    onInput(){
      this.chat.messages.push({message:this.newMessage.nativeElement.value,time:new Date(),sender:this.Sender});
      this.chat.time=this.chat.messages[this.chat.messages.length-1].time;
      this.dataService.updateChat(this.chat).subscribe(()=>{
        this.dataService.fetchChatList().subscribe((data)=>{this.dataService.updateSubject(data)});
      })
      this.newMessage.nativeElement.value='';
    }   

    toggleSender(){
      this.Sender=!this.Sender;
    }

    onDelete(){
      this.dataService.deleteContact(this.chat).subscribe(()=>{
        this.dataService.fetchChatList().subscribe((data)=>{this.dataService.updateSubject(data)});
        this.router.navigate(['']);
        // this.dataService.getChatList().subscribe((data)=>{
        //   if(data.length>0){
        //     // this.router.navigate(['/chats',data[data.length-1].id]);
        //   }
        // })
      });
    }

}