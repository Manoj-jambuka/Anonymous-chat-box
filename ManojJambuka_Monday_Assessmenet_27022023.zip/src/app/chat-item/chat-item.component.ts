import { Component, Input } from '@angular/core';
import { chatItem } from '../model/chat-item';

@Component({
  selector: 'app-chat-item',
  templateUrl: './chat-item.component.html',
  styleUrls: ['./chat-item.component.css']
})
export class ChatItemComponent {
  
  @Input() chat!:chatItem;

  
}
